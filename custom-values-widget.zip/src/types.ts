export type CustomValue = { name: string; fieldKey: string; value?: string };
